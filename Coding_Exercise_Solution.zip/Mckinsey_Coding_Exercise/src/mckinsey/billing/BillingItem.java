package mckinsey.billing;

// This class represents a single billing item in a bill. The item contains information about the quantity, price and item description
public class BillingItem {
	
	private boolean IsGroceryItem;
	private float ItemPrice;
	private int ItemQuatity;
	private int ItemCode;
	private String ItemDescription;
	
	public BillingItem(boolean isGroceryItem, int itemQuantity, float itemPrice, String itemDesc, int itemCode)
	{
		this.IsGroceryItem = isGroceryItem;
		this.ItemPrice = itemPrice;
		this.ItemQuatity = itemQuantity;
		this.ItemCode = itemCode;
		this.ItemDescription = itemDesc;
	}
	
	public boolean IsGroceryItem()
	{
	    return IsGroceryItem;
	}
	
	public float GetItemPrice()
	{
	    return ItemPrice;
	}
	
	public int GetItemQuantity()
	{
		return ItemQuatity;
	}

	public int getItemCode() {
		return ItemCode;
	}

	public String getItemDescription() {
		return ItemDescription;
	}
	
	

}
