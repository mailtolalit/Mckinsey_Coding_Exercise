package mckinsey.billing;

import java.util.ArrayList;
import java.util.Date;

//This class represents the Customer bill, It consists of exactly one  Billing Header and multiple Billing Items
public class CustomerBill {
	
	private static final float NONGROCERY_DISCOUNT_ABOVE_100 = 5;

	public CustomerBill(BillingHeader header, ArrayList<BillingItem> billingItems) {
		this.billingHeader = header;
		this.billingItems = billingItems;
		calculateTotalBill();
		calculateGroceryBill();
	}

	private BillingHeader billingHeader;
	private ArrayList<BillingItem> billingItems;

	private float TotalBill;
	private float GroceryBill;
	private float Non_GroceryBill;

	private void calculateTotalBill() {
		float TotalBill = 0;
		for (BillingItem item : billingItems) {
			TotalBill = TotalBill + item.GetItemPrice()
					* item.GetItemQuantity();
		}

		this.TotalBill = TotalBill;
	}

	private void calculateGroceryBill() {
		float Non_GroceryBill = 0;
		float GroceryBill = 0;
		for (BillingItem item : billingItems) {
			if (!item.IsGroceryItem()) {
				Non_GroceryBill = Non_GroceryBill + item.GetItemPrice()
						* item.GetItemQuantity();
			} else {
				GroceryBill = GroceryBill + item.GetItemPrice()
						* item.GetItemQuantity();
			}
		}

		this.Non_GroceryBill = Non_GroceryBill;
		this.GroceryBill = GroceryBill;

	}
	
	public float GetDiscountOnTotalBill(Float BillAmount)
	{
		// For every 100 $ in the bill give 5$ discount
		float discount = 0;
		discount = ( BillAmount - (BillAmount % 100))/100 * 5;		
		return discount;
	}
	

	public int getBillingItemCount() {
		return billingItems.size();
	}

	public float getTotalBill() {
		return TotalBill;
	}

	public float getGroceryBill() {
		return GroceryBill;
	}

	public float getNon_GroceryBill() {
		return Non_GroceryBill;
	}
	
	public String getBusinessPartnerName() {
		return this.billingHeader.getPartnerName();
	}
	
	public String getBusinessPartnerType() {
		return this.billingHeader.getPartnerType().toString();
	}
	
	public Date getBillingDate() {
		return this.billingHeader.getBillDate();
	}
	
	public float CalculateDiscountOnBill()
	{
	     float partnerTypeBasedDiscount = 0;
         // Discount based on partner Type i.e Affiliate, Customer for more than 2 years, Employee 
         partnerTypeBasedDiscount = this.Non_GroceryBill * this.billingHeader.getBusinessPartner().GetDiscountBasedOnPartnerType()/100;
        
         // Additional discount of 5$ on evry 100$ on bill
         float discountbasedOnBillAmount = GetDiscountOnTotalBill(TotalBill - partnerTypeBasedDiscount);
         
         float discountOnTotalBill = partnerTypeBasedDiscount + discountbasedOnBillAmount;         
                
         return discountOnTotalBill;
         
	}
	
	public float CalculateNetBill()
	{
		return  getTotalBill() - CalculateDiscountOnBill();
	}
	
	
	public String toString()
	{
		StringBuffer out = new StringBuffer("");
		
		out.append("Bill Date: "+ getBillingDate() + "\n");
		out.append("Customer Name:" + getBusinessPartnerName()+ "\n");	
		out.append("Customer Type: "+getBusinessPartnerType()+ "\n");		
		out.append("Total Bill Amount: "+getTotalBill()+ "\n");		
		out.append("Total Non Grocery Bill Amount: "+getNon_GroceryBill()+ "\n");			
		out.append("Discount: "+ CalculateDiscountOnBill()+ "\n");	
		out.append("Net Payable Bill Amount: "+CalculateNetBill()+ "\n");	
		
		return out.toString();
	}

}
