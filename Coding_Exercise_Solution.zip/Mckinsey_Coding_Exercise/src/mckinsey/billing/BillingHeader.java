package mckinsey.billing;

import java.util.Date;

import mckinsey.businesspartner.BusinessPartner;
import mckinsey.businesspartner.BusinessPartnerType;

// This class is used by the CustomerBill. Every bill has exactly one BillingHeader
public class BillingHeader {
	
	public BillingHeader(Date billDate, int billnum, BusinessPartner businessPartner)
	{
	  this.BillDate = billDate;
	  this.BillNumber = billnum;
	  this.partnerName = businessPartner.getPartnerName();
	  this.partnerType = businessPartner.getPartnerType();
	  this.partner = businessPartner;
	}
	
	public BusinessPartnerType getPartnerType() {
		return partnerType;
	}
	public String getPartnerName() {
		return partnerName;
	}

	public Date getBillDate() {
		return BillDate;
	}
	public int getBillNumber() {
		return BillNumber;
	}
	
	public BusinessPartner getBusinessPartner() {
		return partner;
	}	

	private Date BillDate;
	private int BillNumber;
	private BusinessPartnerType partnerType;
	private String partnerName;
	private BusinessPartner partner;

	
}
