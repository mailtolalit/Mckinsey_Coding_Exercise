package mckinsey.solution.tests;

import java.util.ArrayList;
import java.util.Calendar;

import mckinsey.billing.BillingHeader;
import mckinsey.billing.BillingItem;
import mckinsey.billing.CustomerBill;
import mckinsey.businesspartner.BusinessPartner;
import mckinsey.businesspartner.BusinessPartnerType;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import junit.framework.TestCase;

public class CustomerBillTest extends TestCase {

	ArrayList<BillingItem> billingItems = null;

	ArrayList<BillingItem> billingItemsLessThan100 = null;

	ArrayList<BillingItem> billingItemsAllGrocery = null;

	ArrayList<BillingItem> billingItemsAllGroceryGT100 = null;
	
	BusinessPartner Employee_Jolly = new BusinessPartner(
			BusinessPartnerType.EMPLOYEE, "Jolly Sharma");
	
	BusinessPartner Customer_GT_2_Joginder = new BusinessPartner(
			BusinessPartnerType.CUSTOMER_GT_TWO_YEAR, "Joginder Bhalla");
	
	BusinessPartner Customer_LT_2_Yuvraj = new BusinessPartner(
			BusinessPartnerType.CUSTOMER_LT_TWO_YEAR, "Yuraj Singh");
	
	BusinessPartner AFFILIATE_Jasmeet = new BusinessPartner(
			BusinessPartnerType.AFFILIATE, "Jasmeet Singla");

	@Before
	protected void setUp() throws Exception {
		super.setUp();
		billingItems = new ArrayList<BillingItem>();
		BillingItem item1 = new BillingItem(true, 5, 10, "Potato small", 100);
		billingItems.add(item1);
		BillingItem item2 = new BillingItem(true, 3, 15, "Cabbage regular", 101);
		billingItems.add(item2);
		BillingItem item3 = new BillingItem(false, 1, 20, "Table Cloth", 102);
		billingItems.add(item3);
		BillingItem item4 = new BillingItem(false, 1, 50, "Cusion Cover", 103);
		billingItems.add(item4);
		BillingItem item5 = new BillingItem(false, 1, 30, "Vaseline", 104);
		billingItems.add(item5);
		BillingItem item6 = new BillingItem(false, 3, 115, "Crocery Set", 1045);
		billingItems.add(item6);

		billingItemsLessThan100 = new ArrayList<BillingItem>();
		BillingItem item7 = new BillingItem(true, 2, 10, "Potato small", 100);
		billingItemsLessThan100.add(item7);
		BillingItem item8 = new BillingItem(true, 2, 15, "Cabbage regular", 101);
		billingItemsLessThan100.add(item8);
		BillingItem item9 = new BillingItem(false, 1, 30, "Vaseline", 104);
		billingItemsLessThan100.add(item9);

		billingItemsAllGrocery = new ArrayList<BillingItem>();
		BillingItem item10 = new BillingItem(true, 2, 10, "Potato small", 100);
		billingItemsAllGrocery.add(item10);
		BillingItem item11 = new BillingItem(true, 2, 15, "Cabbage regular",
				101);
		billingItemsAllGrocery.add(item11);

		billingItemsAllGroceryGT100 = new ArrayList<BillingItem>();
		BillingItem item12 = new BillingItem(true, 10, 10, "Potato small", 100);
		billingItemsAllGroceryGT100.add(item12);
		BillingItem item13 = new BillingItem(true, 20, 15, "Cabbage regular",
				101);
		billingItemsAllGroceryGT100.add(item13);
	}

	@After
	protected void tearDown() throws Exception {
		super.tearDown();
		billingItems = null;
		billingItemsLessThan100 = null;
		billingItemsAllGroceryGT100 = null;

	}

	/*
	 * Test for Billing amount Greater than 100, for employee
	 */
	@Test
	public void testCalculateDiscountforEmployee() {

		BillingHeader header = new BillingHeader(Calendar.getInstance()
				.getTime(), 1, Employee_Jolly);
		CustomerBill billforEmployee = new CustomerBill(header, billingItems);
		float ExpectedDiscount = 153.5f;
		float ActualDiscount = billforEmployee.CalculateDiscountOnBill();
		assertEquals(ExpectedDiscount, ActualDiscount);
	}

	/*
	 * Test for Billing amount Greater than 100, for Customer more than 2 years
	 */
	@Test
	public void testCalculateDiscountforCustomer2Years() {

		BillingHeader header = new BillingHeader(Calendar.getInstance()
				.getTime(), 1, Customer_GT_2_Joginder);
		CustomerBill billforCustomer = new CustomerBill(header, billingItems);
		float ExpectedDiscount = 47.25f;
		float ActualDiscount = billforCustomer.CalculateDiscountOnBill();
		assertEquals(ExpectedDiscount, ActualDiscount);
	}
	
	/*
	 * Test for Billing amount Greater than 100, for Customer less than 2 years
	 */
	@Test
	public void testCalculateDiscountforCustomerLT2Years() {

		BillingHeader header = new BillingHeader(Calendar.getInstance()
				.getTime(), 1, Customer_LT_2_Yuvraj);
		CustomerBill billforCustomer = new CustomerBill(header, billingItems);
		float ExpectedDiscount = 25f;
		float ActualDiscount = billforCustomer.CalculateDiscountOnBill();
		assertEquals(ExpectedDiscount, ActualDiscount);
	}	

	/*
	 * Test for Billing amount Greater than 100, for affiliate
	 */
	@Test
	public void testCalculateDiscountforAffiliate() {

		BillingHeader header = new BillingHeader(Calendar.getInstance()
				.getTime(), 1, AFFILIATE_Jasmeet);
		CustomerBill billforCustomer = new CustomerBill(header, billingItems);
		float ExpectedDiscount = 64.5f;
		float ActualDiscount = billforCustomer.CalculateDiscountOnBill();
		assertEquals(ExpectedDiscount, ActualDiscount);
	}

	/*
	 * Test for Billing amount less than 100, for employee
	 */
	@Test
	public void testCalculateBillLT100DiscountforEmployee() {

		BillingHeader header = new BillingHeader(Calendar.getInstance()
				.getTime(), 1, Employee_Jolly);
		CustomerBill billforEmployee = new CustomerBill(header,
				billingItemsLessThan100);
		float ExpectedDiscount = 9f;
		float ActualDiscount = billforEmployee.CalculateDiscountOnBill();
		assertEquals(ExpectedDiscount, ActualDiscount);
	}

	/*
	 * Test for Billing amount less than 100, for customer more than 2 years
	 */
	@Test
	public void testCalculateBillLT100DiscountforCustomer2Years() {

		BillingHeader header = new BillingHeader(Calendar.getInstance()
				.getTime(), 1, Customer_GT_2_Joginder);
		CustomerBill billforCustomer = new CustomerBill(header,
				billingItemsLessThan100);
		float ExpectedDiscount = 1.5f;
		float ActualDiscount = billforCustomer.CalculateDiscountOnBill();
		assertEquals(ExpectedDiscount, ActualDiscount);
	}
	
	/*
	 * Test for Billing amount less than 100, for customer less than 2 years
	 */
	@Test
	public void testCalculateBillLT100DiscountforCustomerLT2Years() {

		BillingHeader header = new BillingHeader(Calendar.getInstance()
				.getTime(), 1, Customer_LT_2_Yuvraj);
		CustomerBill billforCustomer = new CustomerBill(header,
				billingItemsLessThan100);
		float ExpectedDiscount = 0;
		float ActualDiscount = billforCustomer.CalculateDiscountOnBill();
		assertEquals(ExpectedDiscount, ActualDiscount);
	}

	/*
	 * Test for Billing amount less than 100, for affiliate
	 */
	@Test
	public void testCalculateBillLT100DiscountforAffiliate() {

		BillingHeader header = new BillingHeader(Calendar.getInstance()
				.getTime(), 1, AFFILIATE_Jasmeet);
		CustomerBill billforCustomer = new CustomerBill(header,
				billingItemsLessThan100);
		float ExpectedDiscount = 3;
		float ActualDiscount = billforCustomer.CalculateDiscountOnBill();
		assertEquals(ExpectedDiscount, ActualDiscount);
	}

	/*
	 * Test for Billing amount for all grocery, Bill less than 100, for employee
	 */
	@Test
	public void testCalculateBillAllGroceryDiscountforEmployee() {

		BillingHeader header = new BillingHeader(Calendar.getInstance()
				.getTime(), 1, Employee_Jolly);
		CustomerBill billforEmployee = new CustomerBill(header,
				billingItemsAllGrocery);
		float ExpectedDiscount = 0;
		float ActualDiscount = billforEmployee.CalculateDiscountOnBill();
		assertEquals(ExpectedDiscount, ActualDiscount);
	}

	/*
	 * Test for Billing amount for all grocery, Bill less than 100, for cutomers more than 2 years
	 */
	@Test
	public void testCalculateBillAllGroceryDiscountforCustomer2Years() {

		BillingHeader header = new BillingHeader(Calendar.getInstance()
				.getTime(), 1, Customer_GT_2_Joginder);
		CustomerBill billforCustomer = new CustomerBill(header,
				billingItemsAllGrocery);
		float ExpectedDiscount = 0;
		float ActualDiscount = billforCustomer.CalculateDiscountOnBill();
		assertEquals(ExpectedDiscount, ActualDiscount);
	}

	/*
	 * Test for Billing amount for all grocery, Bill less than 100, for customers less than 2 years
	 */
	@Test
	public void testCalculateBillAllGroceryDiscountforCustomerLT2Years() {

		BillingHeader header = new BillingHeader(Calendar.getInstance()
				.getTime(), 1, Customer_LT_2_Yuvraj);
		CustomerBill billforCustomer = new CustomerBill(header,
				billingItemsAllGrocery);
		float ExpectedDiscount = 0;
		float ActualDiscount = billforCustomer.CalculateDiscountOnBill();
		assertEquals(ExpectedDiscount, ActualDiscount);
	}
	/*
	 * Test for Billing amount for all grocery, Bill less than 100, for affiliate
	 */
	@Test
	public void testCalculateBillAllGroceryDiscountforAffiliate() {

		BillingHeader header = new BillingHeader(Calendar.getInstance()
				.getTime(), 1, AFFILIATE_Jasmeet);
		CustomerBill billforCustomer = new CustomerBill(header,
				billingItemsAllGrocery);
		float ExpectedDiscount = 0;
		float ActualDiscount = billforCustomer.CalculateDiscountOnBill();
		assertEquals(ExpectedDiscount, ActualDiscount);
	}
   
	/*
	 * Test for Billing amount for all grocery, Bill greater than 100, for employee
	 */
	@Test
	public void testCalculateBillAllGroceryGT100DiscountforEmployee() {

		BillingHeader header = new BillingHeader(Calendar.getInstance()
				.getTime(), 1, Employee_Jolly);
		CustomerBill billforEmployee = new CustomerBill(header,
				billingItemsAllGroceryGT100);
		float ExpectedDiscount = 20;
		float ActualDiscount = billforEmployee.CalculateDiscountOnBill();
		assertEquals(ExpectedDiscount, ActualDiscount);
	}
	/*
	 * Test for Billing amount for all grocery, Bill greater than 100, for customer more than 2 years
	 */
	@Test
	public void testCalculateBillAllGroceryGT100DiscountforCustomer2Years() {

		BillingHeader header = new BillingHeader(Calendar.getInstance()
				.getTime(), 1, Customer_GT_2_Joginder);
		CustomerBill billforCustomer = new CustomerBill(header,
				billingItemsAllGroceryGT100);
		float ExpectedDiscount = 20;
		float ActualDiscount = billforCustomer.CalculateDiscountOnBill();
		assertEquals(ExpectedDiscount, ActualDiscount);
	}

	/*
	 * Test for Billing amount for all grocery, Bill greater than 100, for customer less than 2 years
	 */
	@Test
	public void testCalculateBillAllGroceryGT100DiscountforCustomerLT2Years() {

		BillingHeader header = new BillingHeader(Calendar.getInstance()
				.getTime(), 1, Customer_LT_2_Yuvraj);
		CustomerBill billforCustomer = new CustomerBill(header,
				billingItemsAllGroceryGT100);
		float ExpectedDiscount = 20;
		float ActualDiscount = billforCustomer.CalculateDiscountOnBill();
		assertEquals(ExpectedDiscount, ActualDiscount);
	}

	/*
	 * Test for Billing amount for all grocery, Bill greater than 100, for affiliate
	 */
	@Test
	public void testCalculateBillAllGroceryGT100DiscountforAffiliate() {

		BillingHeader header = new BillingHeader(Calendar.getInstance()
				.getTime(), 1, AFFILIATE_Jasmeet);
		CustomerBill billforCustomer = new CustomerBill(header,
				billingItemsAllGroceryGT100);
		float ExpectedDiscount = 20;
		float ActualDiscount = billforCustomer.CalculateDiscountOnBill();
		assertEquals(ExpectedDiscount, ActualDiscount);
	}

}
