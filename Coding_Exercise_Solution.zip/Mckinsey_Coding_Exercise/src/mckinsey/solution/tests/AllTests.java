package mckinsey.solution.tests;

import junit.framework.Test;
import junit.framework.TestSuite;


public class AllTests {
	
	public static void main(String[] args) {
		junit.textui.TestRunner.run(suite());
	}
	
	public static Test suite() {
		TestSuite suite= new TestSuite("Mckinsey Coding Exercise Tests");
		suite.addTestSuite(CustomerBillTest.class);
		suite.addTestSuite(BusinessPartnerTest.class);
		suite.addTestSuite(CustomerBillTest.class);
		suite.addTestSuite(BillingHeaderTest.class);		
		return suite;
	}

}
