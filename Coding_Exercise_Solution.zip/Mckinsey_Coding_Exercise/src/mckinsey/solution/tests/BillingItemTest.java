package mckinsey.solution.tests;

import junit.framework.TestCase;
import mckinsey.billing.BillingItem;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class BillingItemTest extends TestCase {

	BillingItem item1 = null;
	BillingItem item2 = null;
	BillingItem item3 = null;
	BillingItem item4 = null;
	BillingItem item5 = null;
	BillingItem item6 = null;

	@Before
	protected void setUp() throws Exception {
		super.setUp();

		item1 = new BillingItem(true, 5, 10, "Potato small", 100);
		item2 = new BillingItem(true, 3, 15, "Cabbage regular", 101);
		item3 = new BillingItem(false, 1, 20, "Table Cloth", 102);
		item4 = new BillingItem(false, 1, 50, "Cusion Cover", 103);
		item5 = new BillingItem(false, 1, 30, "Vaseline", 104);
		item6 = new BillingItem(false, 3, 115, "Crocery Set", 105);

	}

	@After
	protected void tearDown() throws Exception {
		super.tearDown();
		item1 = null;
		item2 = null;
		item3 = null;
		item4 = null;
		item5 = null;
		item6 = null;
	}

	@Test
	public void testIsGroceryItem() {		
		boolean actual = item1.IsGroceryItem();		
		assertTrue(actual);
		
		actual = item2.IsGroceryItem();		
		assertTrue(actual);
		
	    actual = item3.IsGroceryItem();		
		assertEquals(actual,false);
		
		actual = item4.IsGroceryItem();		
		assertEquals(actual,false);
		
		actual = item5.IsGroceryItem();		
		assertEquals(actual,false);
		
		actual = item6.IsGroceryItem();		
		assertEquals(actual,false);
	}
	
	@Test
	public void testGetItemCode() {		
		int expectedCode = 100;
		int actualCode = item1.getItemCode();
		assertEquals(actualCode,expectedCode);
		
		expectedCode = 101;
		actualCode = item2.getItemCode();
		assertEquals(actualCode,expectedCode);
		
		expectedCode = 102;
		actualCode = item3.getItemCode();
		assertEquals(actualCode,expectedCode);
		
		expectedCode = 103;
		actualCode = item4.getItemCode();
		assertEquals(actualCode,expectedCode);
		
		expectedCode = 104;
		actualCode = item5.getItemCode();
		assertEquals(actualCode,expectedCode);
		
		expectedCode = 105;
		actualCode = item6.getItemCode();
		assertEquals(actualCode,expectedCode);
		
		
	}
	
	@Test
	public void testGetItemQuantity() {		
		int expectedQuantity = 5;
		int actualQuantity = item1.GetItemQuantity();
		assertEquals(actualQuantity,expectedQuantity);
		
	    expectedQuantity = 3;
		actualQuantity = item2.GetItemQuantity();
		assertEquals(actualQuantity,expectedQuantity);
		
		expectedQuantity = 1;
		actualQuantity = item3.GetItemQuantity();
		assertEquals(actualQuantity,expectedQuantity);
		
		expectedQuantity = 1;
		actualQuantity = item4.GetItemQuantity();
		assertEquals(actualQuantity,expectedQuantity);
		
		expectedQuantity = 1;
		actualQuantity = item5.GetItemQuantity();
		assertEquals(actualQuantity,expectedQuantity);
		
		expectedQuantity = 3;
		actualQuantity = item6.GetItemQuantity();
		assertEquals(actualQuantity,expectedQuantity);
	}
	
	@Test
	public void testGetItemPrice() {		
		float expectedPrice = 10;
		float actualPrice = item1.GetItemPrice();
		assertEquals(actualPrice,expectedPrice);
		
		expectedPrice = 15;
	    actualPrice = item2.GetItemPrice();
		assertEquals(actualPrice,expectedPrice);
		
		expectedPrice = 20;
		actualPrice = item3.GetItemPrice();
		assertEquals(actualPrice,expectedPrice);
		
		expectedPrice = 50;
		actualPrice = item4.GetItemPrice();
		assertEquals(actualPrice,expectedPrice);
		
		expectedPrice = 30;
		actualPrice = item5.GetItemPrice();
		assertEquals(actualPrice,expectedPrice);
		
		expectedPrice = 115;
		actualPrice = item6.GetItemPrice();
		assertEquals(actualPrice,expectedPrice);
	}
	
	@Test
	public void testGetItemDesc() {		
		String expectedDesc = "Potato small";
		String actualDesc = item1.getItemDescription();
		assertEquals(actualDesc,expectedDesc);
		
		expectedDesc = "Cabbage regular";
		actualDesc = item2.getItemDescription();
		assertEquals(actualDesc,expectedDesc);
		
		expectedDesc = "Table Cloth";
		actualDesc = item3.getItemDescription();
		assertEquals(actualDesc,expectedDesc);
		
		expectedDesc = "Cusion Cover";
		actualDesc = item4.getItemDescription();
		assertEquals(actualDesc,expectedDesc);
		
		expectedDesc = "Vaseline";
		actualDesc = item5.getItemDescription();
		assertEquals(actualDesc,expectedDesc);
		
		expectedDesc = "Crocery Set";
		actualDesc = item6.getItemDescription();
		assertEquals(actualDesc,expectedDesc);
		
		
	}

}
