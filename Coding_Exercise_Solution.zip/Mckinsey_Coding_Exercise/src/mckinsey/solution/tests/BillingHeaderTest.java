package mckinsey.solution.tests;

import java.util.Calendar;
import java.util.Date;

import junit.framework.TestCase;
import mckinsey.billing.BillingHeader;
import mckinsey.businesspartner.BusinessPartner;
import mckinsey.businesspartner.BusinessPartnerType;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class BillingHeaderTest extends TestCase {

	BillingHeader header1 = null;
	BillingHeader header2 = null;
	Date currentdate1= Calendar.getInstance().getTime();
	Date currentdate2= Calendar.getInstance().getTime();


	@Before
	protected void setUp() throws Exception {
		super.setUp();

		header1 =  new BillingHeader(currentdate1, 1, new BusinessPartner(BusinessPartnerType.EMPLOYEE, "Joginder Sharma"));
		header2 =  new BillingHeader(currentdate2, 2, new BusinessPartner(BusinessPartnerType.AFFILIATE, "Jolly Sinha"));
	}

	@After
	protected void tearDown() throws Exception {
		super.tearDown();
		header1 = null;
		header2 = null;
	}
	@Test
	public void testGetBillDate() {
		Date expectedDate = currentdate1;
		Date actualDate = header1.getBillDate();
		assertEquals(expectedDate, actualDate);
		
		expectedDate = currentdate2;
		actualDate = header2.getBillDate();
		assertEquals(expectedDate, actualDate);
	}
	
	@Test
	public void testGetBillNumber() {
		int expected = 1;
		int actual = header1.getBillNumber();
		assertEquals(expected, actual);
		
		expected = 2;
		actual = header2.getBillNumber();
		assertEquals(expected, actual);
	}
	
	@Test
	public void testGetBPName() {
		String expected = "Joginder Sharma";
		String actual = header1.getPartnerName();
		assertEquals(expected, actual);
		
		expected = "Jolly Sinha";
		actual = header2.getPartnerName();
		assertEquals(expected, actual);
		
	}
	
	@Test
	public void testGetBPType() {
		String expected = BusinessPartnerType.EMPLOYEE.toString();
		String actual = header1.getPartnerType().toString();
		assertEquals(expected, actual);
		
	    expected = BusinessPartnerType.AFFILIATE.toString();
		actual = header2.getPartnerType().toString();
		assertEquals(expected, actual);
	}

}
