package mckinsey.solution.tests;

import junit.framework.TestCase;

import mckinsey.businesspartner.BusinessPartner;
import mckinsey.businesspartner.BusinessPartnerType;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class BusinessPartnerTest extends TestCase{
	
	BusinessPartner Employee_Jolly =null;
	
	BusinessPartner Customer_GT_2_Joginder = null;
	
	BusinessPartner Customer_LT_2_Yuvraj = null;
	
	BusinessPartner AFFILIATE_Jasmeet = null;
	
	@Before
	protected void setUp() throws Exception {
		super.setUp();
		
		Employee_Jolly = new BusinessPartner(
				BusinessPartnerType.EMPLOYEE, "Jolly Sharma");
		
		Customer_GT_2_Joginder = new BusinessPartner(
				BusinessPartnerType.CUSTOMER_GT_TWO_YEAR, "Joginder Bhalla");
		
		Customer_LT_2_Yuvraj = new BusinessPartner(
				BusinessPartnerType.CUSTOMER_LT_TWO_YEAR, "Yuraj Singh");
		
		AFFILIATE_Jasmeet = new BusinessPartner(
				BusinessPartnerType.AFFILIATE, "Jasmeet Singla");
	}
	
	@After
	protected void tearDown() throws Exception {
		super.tearDown();
		Employee_Jolly =null;
		
		Customer_GT_2_Joginder = null;
		
		Customer_LT_2_Yuvraj = null;
		
		AFFILIATE_Jasmeet = null;
		
	}

	@Test
	public void testGetDiscountBasedOnPartnerTypeEmployee() {
		
		float ExpectedDiscount = 30f;
		float ActualDiscount = Employee_Jolly.GetDiscountBasedOnPartnerType();		
		assertEquals(ExpectedDiscount, ActualDiscount);
		
	}
	
	@Test
	public void testGetDiscountBasedOnPartnerTypeAffilate() {
		
		float ExpectedDiscount = 10f;
		float ActualDiscount = AFFILIATE_Jasmeet.GetDiscountBasedOnPartnerType();		
		assertEquals(ExpectedDiscount, ActualDiscount);
		
	}
	
	@Test
	public void testGetDiscountBasedOnPartnerTypeCustonmerGT2Years() {
		
		float ExpectedDiscount = 5f;
		float ActualDiscount = Customer_GT_2_Joginder.GetDiscountBasedOnPartnerType();		
		assertEquals(ExpectedDiscount, ActualDiscount);
		
	}
	
	@Test
	public void testGetDiscountBasedOnPartnerTypeCustonmerLT2Years() {
		
		float ExpectedDiscount = 0;
		float ActualDiscount = Customer_LT_2_Yuvraj.GetDiscountBasedOnPartnerType();		
		assertEquals(ExpectedDiscount, ActualDiscount);
		
	}

}
