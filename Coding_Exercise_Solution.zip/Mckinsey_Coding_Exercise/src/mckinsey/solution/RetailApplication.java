package mckinsey.solution;

import java.util.ArrayList;
import java.util.Calendar;
import mckinsey.billing.BillingHeader;
import mckinsey.billing.BillingItem;
import mckinsey.billing.CustomerBill;
import mckinsey.businesspartner.BusinessPartner;
import mckinsey.businesspartner.BusinessPartnerType;

// This class demonstrates the sample usage of the Billling discount
public class RetailApplication {
	
	public static void main(String [] args)
	{
       
		BillingHeader header = new BillingHeader(Calendar.getInstance().getTime(), 1, new BusinessPartner(BusinessPartnerType.AFFILIATE, "Joginder Sharma"));
	    
	    ArrayList<BillingItem> billingItems = new ArrayList<BillingItem>();	    
	    
	    BillingItem item1 = new BillingItem(true, 5, 10, "Potato small", 100);
	    billingItems.add(item1);
	    BillingItem item2 = new BillingItem(true, 3, 15, "Cabbage regular", 101);
	    billingItems.add(item2);
	    BillingItem item3 = new BillingItem(false, 1, 20, "Table Cloth", 102);
	    billingItems.add(item3);
	    BillingItem item4 = new BillingItem(false, 1, 50, "Cusion Cover", 103);
	    billingItems.add(item4);
	    BillingItem item5 = new BillingItem(false, 1, 30, "Vaseline", 104);
	    billingItems.add(item5);
	    BillingItem item6 = new BillingItem(false, 3, 115, "Crocery Set", 1045);
	    billingItems.add(item6);
	    
		CustomerBill testbill = new CustomerBill(header, billingItems);			
		
		System.out.print(testbill.toString());
		 
	}
    
}
