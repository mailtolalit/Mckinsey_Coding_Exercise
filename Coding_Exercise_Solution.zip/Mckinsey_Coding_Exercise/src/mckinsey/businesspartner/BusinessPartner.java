package mckinsey.businesspartner;

//This class represents a business partner which can be associated with a bill. Business partner can have different types which is 
// defined in the enumeration BusinessPartner
public class BusinessPartner {

	private BusinessPartnerType PartnerType;
	private String BusinessPartnerName;
	
	private static final float NO_DISCOUNT = 0;
	private static final float EMPLOYEE_DISCOUNT = 30;
	private static final float AFFILIATE_DISCOUNT = 10;
	private static final float CUSTOMER_2YEARS_DISCOUNT = 5;

	public BusinessPartner(BusinessPartnerType partnerType, String name) {
		this.PartnerType = partnerType;
		this.BusinessPartnerName = name;
	}

	public BusinessPartnerType getPartnerType() {
		return PartnerType;
	}
	
	public String getPartnerName() {
		return BusinessPartnerName;
	}

	public float GetDiscountBasedOnPartnerType()
	{
		switch (PartnerType) 
		{
		
		case CUSTOMER_GT_TWO_YEAR:
			return CUSTOMER_2YEARS_DISCOUNT;
		case EMPLOYEE:	
			return EMPLOYEE_DISCOUNT;
		case AFFILIATE:
			return AFFILIATE_DISCOUNT;
		default:
			return NO_DISCOUNT;

		}
		
	}
}
