package mckinsey.businesspartner;

// Enumeration to represent business partner type
public enum BusinessPartnerType {

	 CUSTOMER_GT_TWO_YEAR,EMPLOYEE,AFFILIATE, CUSTOMER_LT_TWO_YEAR
}

